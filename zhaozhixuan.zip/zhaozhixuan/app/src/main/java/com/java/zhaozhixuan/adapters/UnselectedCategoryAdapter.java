package com.java.zhaozhixuan.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.java.zhaozhixuan.R;
import com.java.zhaozhixuan.models.Category;
import java.util.List;

public class UnselectedCategoryAdapter extends RecyclerView.Adapter<UnselectedCategoryAdapter.ViewHolder> {
    private List<Category> unselectedCategories;
    private OnCategoryAddedListener listener;

    // 点击添加回调接口
    public interface OnCategoryAddedListener {
        void onCategoryAdded(Category category);
    }

    public UnselectedCategoryAdapter(List<Category> unselectedCategories, OnCategoryAddedListener listener) {
        this.unselectedCategories = unselectedCategories;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_category, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Category category = unselectedCategories.get(position);
        holder.tvName.setText(category.getName());

        // 未选分类样式：白色背景+灰色文字
        holder.tvName.setBackgroundColor(Color.WHITE);
        holder.tvName.setTextColor(Color.parseColor("#666666"));

        // 点击添加（移到已选列表）
        holder.itemView.setOnClickListener(v -> {
            // 添加添加动画（动态特效，符合作业要求）
            holder.itemView.animate()
                    .alpha(0)
                    .translationY(20)
                    .setDuration(300)
                    .withEndAction(() -> {
                        listener.onCategoryAdded(category);
                    });
        });
    }

    @Override
    public int getItemCount() {
        return unselectedCategories.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tv_category_name);
        }
    }

    // 更新数据（添加后刷新列表）
    public void updateData(List<Category> newList) {
        unselectedCategories = newList;
        notifyDataSetChanged();
    }
}