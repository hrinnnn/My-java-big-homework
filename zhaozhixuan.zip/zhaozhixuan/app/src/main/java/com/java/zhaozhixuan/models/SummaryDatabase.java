package com.java.zhaozhixuan.models;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import com.java.zhaozhixuan.models.HistoryDatabase;
import com.java.zhaozhixuan.models.LikesDatabase;

@Database(entities = {HistoryDatabase.class, LikesDatabase.class}, version = 2, exportSchema = false)
public abstract class SummaryDatabase extends RoomDatabase {

    private static volatile SummaryDatabase INSTANCE;

    public static SummaryDatabase getInstance(Context context) {
        if (INSTANCE == null) {
            synchronized (SummaryDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(context.getApplicationContext(),
                                    SummaryDatabase.class, "summary_database")
                            .fallbackToDestructiveMigration()
                            .build();
                }
            }
        }
        return INSTANCE;
    }

    public abstract HistoryNewsDao newsDao();
    public abstract LikesNewsDao likesDao();
}