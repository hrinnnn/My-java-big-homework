package com.java.zhaozhixuan.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.java.zhaozhixuan.R;
import com.java.zhaozhixuan.activities.NewsDetailActivity;
import com.java.zhaozhixuan.adapters.HistoryAdapter;
import com.java.zhaozhixuan.models.HistoryDatabase;
import com.java.zhaozhixuan.models.SummaryDatabase;

import java.util.ArrayList;
import java.util.List;

public class HistoryFragment extends Fragment {

    private RecyclerView recyclerView;
    private HistoryAdapter adapter;
    private List<HistoryDatabase> historyNewsList = new ArrayList<>();
    private TextView emptyView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_history_category, container, false);

        // 初始化RecyclerView
        recyclerView = view.findViewById(R.id.rv_history_news);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        adapter = new HistoryAdapter(historyNewsList);
        recyclerView.setAdapter(adapter);

        // 空状态提示
        emptyView = view.findViewById(R.id.tv_empty_history);

        // 加载历史记录
        loadHistoryNews();

        return view;
    }

    private void loadHistoryNews() {
        new Thread(() -> {
            // 从数据库获取最近历史记录
            List<HistoryDatabase> newsList = SummaryDatabase.getInstance(
                    getActivity()).newsDao().getRecentHistoryNews(20);

            // 更新UI
            getActivity().runOnUiThread(() -> {
                historyNewsList.clear();
                historyNewsList.addAll(newsList);
                adapter.notifyDataSetChanged();

                // 显示或隐藏空状态
                if (historyNewsList.isEmpty()) {
                    recyclerView.setVisibility(View.GONE);
                    emptyView.setVisibility(View.VISIBLE);
                } else {
                    recyclerView.setVisibility(View.VISIBLE);
                    emptyView.setVisibility(View.GONE);
                }
            });
        }).start();
    }

    private void openNewsDetails(HistoryDatabase news) {

        Intent intent = new Intent(getActivity(), NewsDetailActivity.class);
        startActivity(intent);
    }

    @Override
    public void onResume() {
        super.onResume();
        // 每次页面可见时刷新数据
        loadHistoryNews();
    }
}