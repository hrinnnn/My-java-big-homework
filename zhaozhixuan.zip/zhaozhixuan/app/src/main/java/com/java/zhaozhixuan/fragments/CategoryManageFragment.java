package com.java.zhaozhixuan.fragments;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.java.zhaozhixuan.R;
import com.java.zhaozhixuan.adapters.SelectedCategoryAdapter;
import com.java.zhaozhixuan.adapters.UnselectedCategoryAdapter;
import com.java.zhaozhixuan.models.Category;
import java.util.ArrayList;
import java.util.List;

public class CategoryManageFragment extends Fragment {
    private static final List<String> ALL_CATEGORIES = new ArrayList<>() {{
        add("娱乐");
        add("军事");
        add("教育");
        add("文化");
        add("健康");
        add("财经");
        add("体育");
        add("汽车");
        add("科技");
        add("社会");
    }};

    private final List<Category> selectedCategories = new ArrayList<>();
    private final List<Category> unselectedCategories = new ArrayList<>();

    private SelectedCategoryAdapter selectedAdapter;
    private UnselectedCategoryAdapter unselectedAdapter;

    public interface OnCategorySelectedListener {
        void onCategorySelected(List<String> selectedCategories);
    }

    private OnCategorySelectedListener listener;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof OnCategorySelectedListener) {
            listener = (OnCategorySelectedListener) context;
        } else {
            throw new ClassCastException(context.toString() + " must implement OnCategorySelectedListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_category_manage, container, false);
        initCategories();
        initRecyclerViews(view);
        return view;
    }

    private void initCategories() {
        List<String> defaultSelected = new ArrayList<>();
        defaultSelected.add("科技");
        defaultSelected.add("体育");
        defaultSelected.add("社会");

        for (String categoryName : ALL_CATEGORIES) {
            boolean isSelected = defaultSelected.contains(categoryName);
            Category category = new Category(categoryName, isSelected);
            if (isSelected) {
                selectedCategories.add(category);
            } else {
                unselectedCategories.add(category);
            }
        }
    }

    private void initRecyclerViews(View view) {
        if (getContext() == null) {
            return;
        }

        selectedAdapter = new SelectedCategoryAdapter(selectedCategories, category -> {
            selectedCategories.remove(category);
            unselectedCategories.add(category);
            selectedAdapter.notifyDataSetChanged();
            unselectedAdapter.notifyDataSetChanged();
            notifyCategoryChange();
        });

        unselectedAdapter = new UnselectedCategoryAdapter(unselectedCategories, category -> {
            unselectedCategories.remove(category);
            selectedCategories.add(category);
            selectedAdapter.notifyDataSetChanged();
            unselectedAdapter.notifyDataSetChanged();
            notifyCategoryChange();
        });

        RecyclerView rvSelected = view.findViewById(R.id.rv_selected_categories);
        if (rvSelected != null) {
            rvSelected.setLayoutManager(new GridLayoutManager(getContext(), 4));
            rvSelected.setAdapter(selectedAdapter);
        }

        RecyclerView rvUnselected = view.findViewById(R.id.rv_unselected_categories);
        if (rvUnselected != null) {
            rvUnselected.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
            rvUnselected.setAdapter(unselectedAdapter);
        }
    }

    private void notifyCategoryChange() {
        List<String> selectedCategoryNames = new ArrayList<>();
        for (Category category : selectedCategories) {
            selectedCategoryNames.add(category.getName());
        }
        if (listener != null) {
            listener.onCategorySelected(selectedCategoryNames);
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}