package com.java.zhaozhixuan.models;

/**
 * 分类实体类，对应接口支持的categories参数及“全部”分类
 * 接口支持的分类：娱乐、军事、教育、文化、健康、财经、体育、汽车、科技、社会（来自接口文档）
 * 额外添加“全部”分类（展示所有新闻）
 */
public class Category {
    private String name; // 分类名称（如“科技”“全部”）
    private boolean isSelected; // 是否为已选分类

    public Category(String name, boolean isSelected) {
        this.name = name;
        this.isSelected = isSelected;
    }

    // Getter和Setter
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public boolean isSelected() { return isSelected; }
    public void setSelected(boolean selected) { isSelected = selected; }
}