package com.java.zhaozhixuan.adapters;

import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.fragment.app.Fragment;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;

import com.java.zhaozhixuan.fragments.NewsListFragment;

import java.util.*;

public class TabAdapter extends FragmentStateAdapter {
    private List<String> mCategoryList;
    // 构造方法：接收宿主 Activity（FragmentActivity）
    public TabAdapter(@NonNull FragmentActivity fragmentActivity, List<String> categoryList) {
        super(fragmentActivity);
        mCategoryList = categoryList;
    }

    // 核心方法 1：创建 Fragment（ViewPager2 滑动时调用）
    @NonNull
    @Override
    public Fragment createFragment(int position) {
        return NewsListFragment.newInstance(mCategoryList.get(position));
    }

    // 核心方法 2：返回页面总数（TabLayout 的标签数量）
    @Override
    public int getItemCount() {
        return mCategoryList.size();
    }

    // 辅助方法：给 TabLayout 提供标签标题
    public String getTabTitle(int position) {
        return mCategoryList.get(position);
    }
}
