package com.java.zhaozhixuan.models;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class NewsApiClient {
    private static final String BASE_URL = "https://api2.newsminer.net/svc/news/queryNewsList";
    private final OkHttpClient client;
    private final Gson gson;

    public NewsApiClient() {
        client = new OkHttpClient();
        gson = new Gson();
    }

    public void getNewsList(int size, String startDate, String endDate, String words, String categories, int page, final NewsCallback callback) {
        String url = String.format("%s?size=%d&startDate=%s&endDate=%s&words=%s&categories=%s&page=%d",
                BASE_URL, size, startDate, endDate, words, categories, page);

        Log.i("news", "getNewsList: url = " + url);
        Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                new Handler(Looper.getMainLooper()).post(() -> callback.onError(e.getMessage()));
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (response.isSuccessful() && response.body() != null) {
                    String json = response.body().string();
                    Log.i("news", "onResponse: json = " + json);
                    List<NewsItem> newsList = parseNewsJson(json);
                    Log.i("news", "onResponse: newsList.size = " + newsList.size());
                    new Handler(Looper.getMainLooper()).post(() -> callback.onSuccess(newsList));
                } else {
                    new Handler(Looper.getMainLooper()).post(() -> callback.onError("请求失败，状态码: " + response.code()));
                }
            }
        });
    }

    private List<NewsItem> parseNewsJson(String json) {
        List<NewsItem> newsList = new ArrayList<>();
        try {
            // 解析根 JSON 对象
            JsonObject rootObject = JsonParser.parseString(json).getAsJsonObject();

            // 检查是否包含接口文档中指定的 "data" 数组
            if (!rootObject.has("data") || rootObject.get("data").isJsonNull()) {
                Log.w("news", "未找到有效新闻列表（data 字段缺失或为空）");
                return newsList;
            }

            JsonArray newsArray = rootObject.getAsJsonArray("data");

            // 遍历新闻数组，解析每条新闻
            for (int i = 0; i < newsArray.size(); i++) {
                if (!newsArray.get(i).isJsonObject()) {
                    Log.w("news", "第" + i + "条新闻格式错误（非 JSON 对象），跳过解析");
                    continue;
                }

                JsonObject newsObject = newsArray.get(i).getAsJsonObject();

                // 提取接口返回的核心字段（严格对应 NewsItem 的构造参数）
                String title = getSafeString(newsObject, "title");
                String source = getSafeString(newsObject, "publisher");
                String pubTime = getSafeString(newsObject, "publishTime");
                String content = getSafeString(newsObject, "content");

                // 构造 NewsItem 对象（使用现有构造方法）
                NewsItem newsItem = new NewsItem(title, source, pubTime, content);

                // 补充非构造参数的字段（视频、图片链接）
                newsItem.setVideoUrl(getSafeString(newsObject, "video"));
                newsItem.setImageUrl(getSafeString(newsObject, "image")); // 接口文档提示 image 可能为空

                // 本地状态字段无需在这里设置（保持默认值：未读、未收藏）

                newsList.add(newsItem);
            }

        } catch (Exception e) {
            Log.e("news", "新闻 JSON 解析失败：" + e.getMessage(), e);
        }
        return newsList;
    }

    /**
     * 安全提取字符串字段，处理字段缺失、空值或类型错误（适配接口文档中 "部分字段可能为空" 的情况）
     */
    private String getSafeString(JsonObject jsonObject, String fieldName) {
        // 字段不存在或为 null 时返回空字符串
        if (!jsonObject.has(fieldName) || jsonObject.get(fieldName).isJsonNull()) {
            return "";
        }
        // 尝试转换为字符串，避免类型不匹配导致崩溃
        try {
            return jsonObject.get(fieldName).getAsString();
        } catch (Exception e) {
            Log.w("news", "字段[" + fieldName + "]类型错误，返回空字符串");
            return "";
        }
    }

    public interface NewsCallback {
        void onSuccess(List<NewsItem> newsList);
        void onError(String errorMessage);
    }
}