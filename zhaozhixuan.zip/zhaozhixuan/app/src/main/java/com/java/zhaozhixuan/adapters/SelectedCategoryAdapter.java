package com.java.zhaozhixuan.adapters;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.java.zhaozhixuan.R;
import com.java.zhaozhixuan.models.Category;
import java.util.List;

public class SelectedCategoryAdapter extends RecyclerView.Adapter<SelectedCategoryAdapter.ViewHolder> {
    private List<Category> selectedCategories;
    private OnCategoryRemovedListener listener;

    // 点击删除回调接口
    public interface OnCategoryRemovedListener {
        void onCategoryRemoved(Category category);
    }

    public SelectedCategoryAdapter(List<Category> selectedCategories, OnCategoryRemovedListener listener) {
        this.selectedCategories = selectedCategories;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_category, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Category category = selectedCategories.get(position);
        holder.tvName.setText(category.getName());

        // 已选分类样式：深色背景+白色文字
        holder.tvName.setBackgroundColor(holder.itemView.getContext().getResources().getColor(R.color.selected_category_bg));
        holder.tvName.setTextColor(Color.WHITE);

        // 点击删除（移到未选列表）
        holder.itemView.setOnClickListener(v -> {
            // 添加删除动画（动态特效，符合作业要求）
            holder.itemView.animate()
                    .alpha(0)
                    .scaleX(0.8f)
                    .scaleY(0.8f)
                    .setDuration(300)
                    .withEndAction(() -> {
                        listener.onCategoryRemoved(category);
                    });
        });
    }

    @Override
    public int getItemCount() {
        return selectedCategories.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvName;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvName = itemView.findViewById(R.id.tv_category_name);
        }
    }

    // 更新数据（删除后刷新列表）
    public void updateData(List<Category> newList) {
        selectedCategories = newList;
        notifyDataSetChanged();
    }
}