package com.java.zhaozhixuan.models;

import android.os.Parcel;
import android.os.Parcelable;

import androidx.annotation.NonNull;

public class NewsItem implements Parcelable {
    private String title;
    private String newsId;
    private String source;
    private String pubTime;
    private String content;
    private String videoUrl;
    private String imageUrl;

    public NewsItem(String title, String source, String pubTime, String content) {
        this.title = title;
        this.source = source;
        this.pubTime = pubTime;
        this.content = content;
    }
    public void setNewsId(String newsId) {
        this.newsId = newsId;
    }
    public String getNewsId() {
        return newsId;
    }
    public void setVideoUrl(String videoUrl) {
        this.videoUrl = videoUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    // Getter 方法（如果需要）
    public String getTitle() {
        return title;
    }

    public String getSource() {
        return source;
    }

    public String getPubTime() {
        return pubTime;
    }

    public String getContent() {
        return content;
    }

    public String getVideoUrl() {
        return videoUrl;
    }

    public String getImageUrl() {
        return imageUrl;
    }
    // 实现 Parcelable 接口
    protected NewsItem(Parcel in) {
        title = in.readString();
        newsId = in.readString();
        source = in.readString();
        pubTime = in.readString();
        content = in.readString();
        videoUrl = in.readString();
        imageUrl = in.readString();
    }
    public static final Creator<NewsItem> CREATOR = new Creator<NewsItem>() {
        @Override
        public NewsItem createFromParcel(Parcel in) {
            return new NewsItem(in);
        }
        @Override
        public NewsItem[] newArray(int size) {
            return new NewsItem[size];
        }
    };
    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(@NonNull Parcel dest, int flags) {
        dest.writeString(title);
        dest.writeString(newsId);
        dest.writeString(source);
        dest.writeString(pubTime);
        dest.writeString(content);
        dest.writeString(videoUrl);
        dest.writeString(imageUrl);
    }
}