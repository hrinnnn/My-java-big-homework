package com.java.zhaozhixuan.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.java.zhaozhixuan.R;
import com.java.zhaozhixuan.adapters.LikesAdapter;
import com.java.zhaozhixuan.models.LikesDatabase;
import com.java.zhaozhixuan.models.SummaryDatabase;
import java.util.ArrayList;
import java.util.List;

public class LikesFragment extends Fragment {

    private RecyclerView rvLikes;
    private LikesAdapter likesAdapter;
    private List<LikesDatabase> likesList = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_likes_category, container, false);
        rvLikes = view.findViewById(R.id.rv_likes);
        rvLikes.setLayoutManager(new LinearLayoutManager(getContext()));
        likesAdapter = new LikesAdapter(likesList);
        rvLikes.setAdapter(likesAdapter);
        loadLikesData();
        return view;
    }

    private void loadLikesData() {
        new Thread(() -> {
            List<LikesDatabase> data = SummaryDatabase.getInstance(requireContext())
                    .likesDao()
                    .getAllLikedNews();
            likesList.clear();
            likesList.addAll(data);
            requireActivity().runOnUiThread(() -> likesAdapter.notifyDataSetChanged());
        }).start();
    }
}