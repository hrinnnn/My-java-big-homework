package com.java.zhaozhixuan.adapters;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.java.zhaozhixuan.R;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.java.zhaozhixuan.activities.NewsDetailActivity;
import com.java.zhaozhixuan.models.NewsItem;
import java.util.List;

import com.java.zhaozhixuan.models.NewsItem;
import java.util.List;  // 如果直接使用List而不是具体实现类
public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.NewsViewHolder> {
    private List<NewsItem> newsList;

    // 构造函数保持不变...
    // 2. 构造函数
    public NewsAdapter(List<NewsItem> newsList) {
        this.newsList = newsList;
    }

    @NonNull
    @Override
    public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_news, parent, false);
        return new NewsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NewsViewHolder holder, int position) {
        NewsItem item = newsList.get(position);
        holder.tvTitle.setText(item.getTitle());
//        holder.tvTitle.settextcolor(color.black);
//        holder.tvSummary.setText(item.getSummary());
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(holder.itemView.getContext(), NewsDetailActivity.class);
            intent.putExtra("newsItem", item);
            // 处理点击事件，例如跳转到新闻详情页面
            holder.itemView.getContext().startActivity(intent);
        });
    }
    // 必须实现的方法：返回数据项总数
    @Override
    public int getItemCount() {
        return newsList.size();  // 返回newsList的大小
    }

    // ViewHolder 内部类改为直接持有View引用
    static class NewsViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitle;
        TextView tvSummary;

        public NewsViewHolder(View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tv_title); // 确保ID匹配XML
            tvSummary = itemView.findViewById(R.id.tv_summary);
        }
    }
}

