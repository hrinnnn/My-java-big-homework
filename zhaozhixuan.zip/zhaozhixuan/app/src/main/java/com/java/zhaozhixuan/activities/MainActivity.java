package com.java.zhaozhixuan.activities;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.java.zhaozhixuan.R;
import android.widget.ImageButton;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.java.zhaozhixuan.adapters.ViewPagerAdapter;
import com.java.zhaozhixuan.fragments.CategoryManageFragment;
import com.java.zhaozhixuan.fragments.HistoryFragment;
import com.java.zhaozhixuan.fragments.LikesFragment;
import com.java.zhaozhixuan.fragments.NewsFragment;
import androidx.fragment.app.*;
import android.widget.LinearLayout;
import android.widget.EditText;
// 还有 AppCompatActivity 等基础类的导入，一般创建 Activity 时默认会有

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity implements CategoryManageFragment.OnCategorySelectedListener {
    //extern all things
    private LinearLayout searchContainer;
    private EditText etSearch;
    private ImageButton btnSearch;
    private TabLayout tabLayout;
    private ViewPager2 viewPager;
    private BottomNavigationView bottomNav;

    private NewsFragment newsFragment;
    private LikesFragment likesFragment;
    private HistoryFragment historyFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        //init Veiws
        initFragment();
        setupBottomNavigation();
        showFragment(newsFragment);
    }

    private void initFragment(){
        newsFragment = new NewsFragment();
        historyFragment= new HistoryFragment();
        likesFragment = new LikesFragment();
    }
    private void setupBottomNavigation() {
        findViewById(R.id.likes_button).setOnClickListener(v -> showFragment(likesFragment));
        findViewById(R.id.history_button).setOnClickListener(v -> showFragment(historyFragment));
        findViewById(R.id.news_button).setOnClickListener(v -> showFragment(newsFragment));
    }
    private void showFragment(Fragment fragment) {
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction transaction = fm.beginTransaction();

        // 隐藏所有已添加的Fragment
        if (newsFragment != null) transaction.hide(newsFragment);
        if (likesFragment != null) transaction.hide(likesFragment);
        if (historyFragment != null) transaction.hide(historyFragment);

        // 显示目标Fragment
        if (!fragment.isAdded()) {
            transaction.add(R.id.fragment_container, fragment);
        } else {
            transaction.show(fragment);
        }

        transaction.commit();
    }
    @Override
    public void onCategorySelected(List<String> selectedCategories) {
        if (newsFragment != null) {
            newsFragment.updateTabLayout(selectedCategories);
        }
    }

}