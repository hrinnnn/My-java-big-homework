package com.java.zhaozhixuan.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import com.java.zhaozhixuan.R;
import com.java.zhaozhixuan.fragments.CategoryManageFragment;

import java.util.ArrayList;
import java.util.List;

public class CategoryManageActivity extends AppCompatActivity implements CategoryManageFragment.OnCategorySelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_manage);

        // 初始化返回按钮
        ImageButton backButton = findViewById(R.id.back_button);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 关闭当前 Activity
                finish();
            }
        });

        // 加载 CategoryManageFragment
        CategoryManageFragment fragment = new CategoryManageFragment();
        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container, fragment);
        fragmentTransaction.commit();
    }

    @Override
    public void onCategorySelected(List<String> selectedCategories) {
        // 将选中的分类信息通过 Intent 返回给上一个 Activity
        Intent resultIntent = new Intent();
        resultIntent.putStringArrayListExtra("selectedCategories", new ArrayList<>(selectedCategories));
        setResult(RESULT_OK, resultIntent);
    }
}