package com.java.zhaozhixuan.activities;

import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.java.zhaozhixuan.models.HistoryDatabase;
import com.java.zhaozhixuan.models.SummaryDatabase;
import com.java.zhaozhixuan.R;
import com.java.zhaozhixuan.models.NewsItem;

public class NewsDetailActivity extends AppCompatActivity {
    private NewsItem mNewsItem;
    private TextView mTitleTv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_news_detail);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        initIntentData();
        initView();
        saveNewsToHistory();
    }


    private void initView() {
        findViewById(R.id.back).setOnClickListener(v -> finish());
        mTitleTv = findViewById(R.id.news_title);
        mTitleTv.setText(mNewsItem.getTitle());
        // 显示新闻内容
        TextView newsContentTv = findViewById(R.id.news_content);
        if (mNewsItem != null && mNewsItem.getContent() != null) {
            newsContentTv.setText(mNewsItem.getContent());
        } else {
            newsContentTv.setText("No news content available");
        }
    }

    private void initIntentData() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            mNewsItem = getIntent().getParcelableExtra("newsItem", NewsItem.class);
        } else {
            mNewsItem = getIntent().getParcelableExtra("newsItem");
        }
        if (mNewsItem != null) {
            Log.d("NewsDetailActivity", "Received news item: " + mNewsItem.getTitle());
        } else {
            Log.e("NewsDetailActivity", "News item is null");
        }
    }
    private void saveNewsToHistory() {
        if (mNewsItem != null) {
            new Thread(() -> {
                HistoryDatabase historyDatabase = new HistoryDatabase(
                        mNewsItem.getNewsId(),
                        mNewsItem.getTitle(),
                        mNewsItem.getContent(),
                        mNewsItem.getSource(),
                        mNewsItem.getPubTime(),
                        mNewsItem.getImageUrl(),
                        mNewsItem.getVideoUrl()
                );
                SummaryDatabase.getInstance(this).newsDao().insertHistoryNews(historyDatabase);
            }).start();
        }
    }

}