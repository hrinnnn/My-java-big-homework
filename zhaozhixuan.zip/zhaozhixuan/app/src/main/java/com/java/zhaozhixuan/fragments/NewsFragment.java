package com.java.zhaozhixuan.fragments;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.java.zhaozhixuan.R;
import com.java.zhaozhixuan.activities.CategoryManageActivity;
import com.java.zhaozhixuan.adapters.NewsAdapter;
import com.java.zhaozhixuan.adapters.TabAdapter;
import com.java.zhaozhixuan.models.NewsItem;
import com.java.zhaozhixuan.models.NewsApiClient;
import java.util.ArrayList;
import java.util.List;

public class NewsFragment extends Fragment {
    private String category;
    private TabLayout tabLayout;
    private ViewPager2 viewPager;
    private Button btnManageCategories;

    private EditText etSearch;
    private ImageButton btnSearch;

    private NewsApiClient newsApiClient;
    private List<String> mCategoryList = new ArrayList<>();

    public static NewsFragment newInstance(String category) {
        NewsFragment fragment = new NewsFragment();
        Bundle args = new Bundle();
        args.putString("category", category);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            category = getArguments().getString("category");
        }
        newsApiClient = new NewsApiClient();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_news_category, container, false);

        initViews(view);
        setupTabLayoutAndViewPager();
        setupSearch();
        setupButtonClickListener();
        return view;
    }

    private void initViews(View view) {
        etSearch = view.findViewById(R.id.et_search);
        btnSearch = view.findViewById(R.id.btn_search);
        tabLayout = view.findViewById(R.id.tab_layout);
        viewPager = view.findViewById(R.id.view_pager);
        btnManageCategories = view.findViewById(R.id.btn_manage_categories);
    }

    private void setupTabLayoutAndViewPager() {
        if (mCategoryList.isEmpty()) {
            mCategoryList.add("科技");
            mCategoryList.add("娱乐");
            mCategoryList.add("体育");
            mCategoryList.add("军事");
            mCategoryList.add("教育");
            mCategoryList.add("文化");
            mCategoryList.add("健康");
            mCategoryList.add("财经");
            mCategoryList.add("汽车");
            mCategoryList.add("社会");
        }

        TabAdapter tabAdapter = new TabAdapter(requireActivity(), mCategoryList);
        viewPager.setAdapter(tabAdapter);

        new TabLayoutMediator(tabLayout, viewPager, (tab, position) ->
                tab.setText(mCategoryList.get(position))
        ).attach();

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                category = mCategoryList.get(position);
            }
        });
    }

    private void setupButtonClickListener() {
        btnManageCategories.setOnClickListener(v -> {
            if (getActivity() != null) {
                Intent intent = new Intent(getActivity(), CategoryManageActivity.class);
                startActivity(intent);
            } else {
                Toast.makeText(requireContext(), "无法跳转，请稍后重试", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setupSearch() {
        btnSearch.setOnClickListener(v -> {
            String searchKeyword = etSearch.getText().toString().trim();
            if (!TextUtils.isEmpty(searchKeyword)) {
//                loadSearchNews(searchKeyword);
            } else {
                Toast.makeText(requireContext(), "请输入搜索关键词", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void updateTabLayout(List<String> selectedCategories) {
        if (tabLayout != null) {
            tabLayout.removeAllTabs();
            for (String category : selectedCategories) {
                TabLayout.Tab tab = tabLayout.newTab();
                tab.setText(category);
                tabLayout.addTab(tab);
            }
        }
    }
}