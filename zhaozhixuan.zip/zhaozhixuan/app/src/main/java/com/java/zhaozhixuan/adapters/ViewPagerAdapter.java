package com.java.zhaozhixuan.adapters;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import com.java.zhaozhixuan.fragments.CommonFragment;
import java.util.List;

public class ViewPagerAdapter extends FragmentStateAdapter {

    private final List<String> categoryList;

    public ViewPagerAdapter(@NonNull FragmentActivity fragmentActivity, List<String> categoryList) {
        super(fragmentActivity);
        this.categoryList = categoryList;
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        String category = categoryList.get(position);
        return CommonFragment.newInstance(category);
    }

    @Override
    public int getItemCount() {
        return categoryList.size();
    }
}