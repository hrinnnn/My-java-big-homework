package com.java.zhaozhixuan.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.java.zhaozhixuan.R;
import com.java.zhaozhixuan.models.HistoryDatabase;
import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder> {

    private final List<HistoryDatabase> historyList;

    public HistoryAdapter(List<HistoryDatabase> historyList) {
        this.historyList = historyList;
    }

    @NonNull
    @Override
    public HistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_history, parent, false);
        return new HistoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull HistoryViewHolder holder, int position) {
        HistoryDatabase history = historyList.get(position);
        holder.titleTextView.setText(history.getTitle());
        holder.sourceTextView.setText(history.getSource());
        holder.pubTimeTextView.setText(history.getPubTime());
        holder.contentTextView.setText(history.getContent());
        Glide.with(holder.itemView.getContext())
                .load(history.getImageUrl())
//                .placeholder(R.drawable.placeholder_image)
//                .error(R.drawable.error_image)
                .into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return historyList.size();
    }

    static class HistoryViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView;
        TextView sourceTextView;
        TextView pubTimeTextView;
        TextView contentTextView;
        ImageView imageView;

        HistoryViewHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.title_text_view);
            sourceTextView = itemView.findViewById(R.id.source_text_view);
            pubTimeTextView = itemView.findViewById(R.id.pub_time_text_view);
            contentTextView = itemView.findViewById(R.id.content_text_view);
            imageView = itemView.findViewById(R.id.image_view);
        }
    }
}