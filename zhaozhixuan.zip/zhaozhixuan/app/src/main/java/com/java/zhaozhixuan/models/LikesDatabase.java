package com.java.zhaozhixuan.models;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import java.io.Serializable;
import java.util.Date;

/**
 * 点赞记录表实体类，存储用户点赞过的新闻
 * 关联接口返回的核心字段，支持离线查看
 */
@Entity(tableName = "likes_news")
public class LikesDatabase implements Serializable {
    @PrimaryKey(autoGenerate = true)
    private int id; // 自增ID，用于本地唯一标识
    private String newsId; // 新闻唯一ID（对应接口返回的新闻ID）
    private String title; // 新闻标题
    private String content; // 新闻正文（支持离线访问）
    private String source; // 新闻来源（接口返回的source字段）
    private String pubTime; // 发布时间（接口返回的pubTime字段，原格式存储）
    private String imageUrl; // 图片链接（接口返回的imageUrl字段）
    private String videoUrl; // 视频链接（接口返回的videoUrl字段）
    private boolean isLiked; // 点赞状态

    // 构造方法：从接口返回的新闻数据初始化
    public LikesDatabase(String newsId, String title, String content, String source,
                         String pubTime, String imageUrl, String videoUrl) {
        this.newsId = newsId;
        this.title = title;
        this.content = content;
        this.source = source;
        this.pubTime = pubTime;
        this.imageUrl = imageUrl;
        this.videoUrl = videoUrl;
        this.isLiked = true; // 点赞后默认标记为已点赞
    }

    // Getter和Setter方法
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNewsId() { return newsId; }
    public void setNewsId(String newsId) { this.newsId = newsId; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getSource() { return source; }
    public void setSource(String source) { this.source = source; }

    public String getPubTime() { return pubTime; }
    public void setPubTime(String pubTime) { this.pubTime = pubTime; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public String getVideoUrl() { return videoUrl; }
    public void setVideoUrl(String videoUrl) { this.videoUrl = videoUrl; }

    public boolean isLiked() { return isLiked; }
    public void setLiked(boolean liked) { isLiked = liked; }
}