package com.java.zhaozhixuan.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.java.zhaozhixuan.R;
import com.java.zhaozhixuan.models.LikesDatabase;
import java.util.List;

public class LikesAdapter extends RecyclerView.Adapter<LikesAdapter.LikesViewHolder> {

    private final List<LikesDatabase> likesList;

    public LikesAdapter(List<LikesDatabase> likesList) {
        this.likesList = likesList;
    }

    @NonNull
    @Override
    public LikesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // 加载 item_likes.xml 布局文件
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_likes, parent, false);
        return new LikesViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull LikesViewHolder holder, int position) {
        LikesDatabase likes = likesList.get(position);
        // 绑定新闻标题
        holder.titleTextView.setText(likes.getTitle());
        // 绑定新闻来源
        holder.sourceTextView.setText(likes.getSource());
        // 绑定发布时间
        holder.pubTimeTextView.setText(likes.getPubTime());
        // 绑定新闻内容
        holder.contentTextView.setText(likes.getContent());
        // 使用 Glide 加载新闻配图
        Glide.with(holder.itemView.getContext())
                .load(likes.getImageUrl())
//                .placeholder(R.drawable.placeholder_image) // 占位图
//                .error(R.drawable.error_image) // 加载失败显示的图片
                .into(holder.imageView);
    }

    @Override
    public int getItemCount() {
        return likesList.size();
    }

    static class LikesViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView;
        TextView sourceTextView;
        TextView pubTimeTextView;
        TextView contentTextView;
        ImageView imageView;

        LikesViewHolder(@NonNull View itemView) {
            super(itemView);
            // 初始化视图组件
            titleTextView = itemView.findViewById(R.id.title_text_view);
            sourceTextView = itemView.findViewById(R.id.source_text_view);
            pubTimeTextView = itemView.findViewById(R.id.pub_time_text_view);
            contentTextView = itemView.findViewById(R.id.content_text_view);
            imageView = itemView.findViewById(R.id.image_view);
        }
    }
}