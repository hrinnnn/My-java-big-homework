package com.java.zhaozhixuan.fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.java.zhaozhixuan.R;
import com.java.zhaozhixuan.adapters.NewsAdapter;
import com.java.zhaozhixuan.models.NewsApiClient;
import com.java.zhaozhixuan.models.NewsItem;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link NewsListFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class NewsListFragment extends Fragment {

    private static final String CATEGORY = "categories";

    private String mCategory;
    private String mParam2;

    public NewsListFragment() {
        // Required empty public constructor
    }
    private RecyclerView recyclerView;
    private NewsAdapter adapter;
    private List<NewsItem> newsList = new ArrayList<>();
    private LinearLayoutManager layoutManager;
    private NewsApiClient newsApiClient;

    public static NewsListFragment newInstance(String categories) {
        NewsListFragment fragment = new NewsListFragment();
        Bundle args = new Bundle();
        args.putString(CATEGORY, categories);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mCategory = getArguments().getString(CATEGORY);
            Log.i("news", "onCreate: category = " + mCategory);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_news_list, container, false);
    }

    @Override
    public void onViewCreated( View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        recyclerView = view.findViewById(R.id.rv_news);
        setupRecyclerView();
        newsApiClient = new NewsApiClient();
        fetchNewsData();
    }

    private void setupRecyclerView() {
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);
        adapter = new NewsAdapter(newsList);
        recyclerView.setAdapter(adapter);
    }
    private void fetchNewsData() {
        newsApiClient.getNewsList(15, "2024-07-01 13:12:45", "2024-07-03 18:42:20", "特朗普", mCategory, 1, new NewsApiClient.NewsCallback() {
            @Override
            public void onSuccess(List<NewsItem> news) {
                Log.i("news", "onSuccess: news = " + news);
                newsList.clear();
                newsList.addAll(news);
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onError(String errorMessage) {
                Log.i("news", "onError: errorMessage = " + errorMessage);
                Toast.makeText(getActivity(), errorMessage, Toast.LENGTH_SHORT).show();
            }
        });
    }
}