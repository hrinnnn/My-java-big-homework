package com.java.zhaozhixuan.models;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

/**
 * HistoryNewsDao 接口用于定义对历史新闻表的数据库操作。
 * 使用 Room 数据库框架的注解来实现数据库的增删改查操作。
 */
@Dao
public interface HistoryNewsDao {

    /**
     * 向历史新闻表中插入一条历史新闻记录。
     * @param historyDatabase 要插入的历史新闻记录对象。
     */
    @Insert
    void insertHistoryNews(HistoryDatabase historyDatabase);

    /**
     * 从历史新闻表中获取所有的历史新闻记录。
     * @return 包含所有历史新闻记录的列表。
     */
    @Query("SELECT * FROM history_news ORDER BY pubTime DESC")
    List<HistoryDatabase> getAllHistoryNews();

    /**
     * 从历史新闻表中获取最近的若干条历史新闻记录。
     * @param limit 要获取的记录数量上限。
     * @return 包含最近历史新闻记录的列表。
     */
    @Query("SELECT * FROM history_news ORDER BY pubTime DESC LIMIT :limit")
    List<HistoryDatabase> getRecentHistoryNews(int limit);

    /**
     * 根据新闻 ID 从历史新闻表中删除一条历史新闻记录。
     * @param newsId 要删除的历史新闻记录的新闻 ID。
     */
    @Query("DELETE FROM history_news WHERE newsId = :newsId")
    void deleteHistoryNewsById(String newsId);

    /**
     * 从历史新闻表中删除所有的历史新闻记录。
     */
    @Query("DELETE FROM history_news")
    void deleteAllHistoryNews();

    /**
     * 批量删除历史新闻记录。
     * @param historyDatabases 要删除的历史新闻记录对象列表。
     */
    @Delete
    void deleteHistoryNews(List<HistoryDatabase> historyDatabases);
}