package com.java.zhaozhixuan.models;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface LikesNewsDao {
    @Insert
    void insertLikedNews(LikesDatabase likesDatabase);

    @Query("SELECT * FROM likes_news")
    List<LikesDatabase> getAllLikedNews();

    @Query("DELETE FROM likes_news WHERE newsId = :newsId")
    void unLikeNews(String newsId);
}